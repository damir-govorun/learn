var sideA = 4, perimeter = 4 * sideA;
console.log("Perimeter is: " + perimeter);

